# backend/app/routes_admin.py
# ─────────────────────────────────────────────────────────────────────────────
# CHANGES FROM v1
# ─────────────────────────────────────────────────────────────────────────────
# 1. summarize_tender  — passes (tender_id, session) to build_user_summary
#                        instead of building an applications list first.
#                        Route signature is IDENTICAL.
#
# 2. create_tender / publish_tender  — calls pipeline.index_tender in a
#                        FastAPI BackgroundTask so it runs after the response.
#                        All other admin routes are UNCHANGED.
# ─────────────────────────────────────────────────────────────────────────────

import json
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks

from .db import get_session
from .models import Tender, Application, User
from .auth import require_admin               # your existing dep — do not change
from . import ai_agent
from .pipeline import index_tender

router = APIRouter()


# ── Paste your existing admin routes above this line, then replace only
#    the two functions below. ────────────────────────────────────────────────


# CHANGED — was: build list of dicts → call build_user_summary(list)
# NOW      —      call build_user_summary(tender_id, session)
@router.post("/tenders/{tender_id}/summary")
def summarize_tender(tender_id: int, admin: User = Depends(require_admin)):
    with get_session() as session:
        tender = session.get(Tender, tender_id)
        if not tender:
            raise HTTPException(status_code=404, detail="Tender not found")

        # Pure DB read — no Ollama call
        result = ai_agent.build_user_summary(tender_id, session)

        # Cache result on the Tender row (same behaviour as before)
        tender.summary_json = json.dumps(result)
        session.add(tender)
        session.commit()

    return result


# CHANGED — add BackgroundTasks parameter to trigger index_tender after response
# The route path, method, and response are IDENTICAL to what you had.
# If you already have a "create tender" endpoint, add `background_tasks`
# the same way and call background_tasks.add_task(index_tender, tender.id)
# right before the return statement.
#
# Example (adapt to your actual create/publish endpoint):
@router.post("/tenders/{tender_id}/publish")
def publish_tender(
    tender_id: int,
    background_tasks: BackgroundTasks,
    admin: User = Depends(require_admin),
):
    with get_session() as session:
        tender = session.get(Tender, tender_id)
        if not tender:
            raise HTTPException(status_code=404, detail="Tender not found")
        if tender.status not in ("draft", "indexing"):
            raise HTTPException(status_code=400, detail="Tender already published")

    # index_tender runs AFTER this response is sent — does not block the caller
    background_tasks.add_task(index_tender, tender_id)

    return {"tender_id": tender_id, "status": "indexing_started"}
