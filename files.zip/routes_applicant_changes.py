# backend/app/routes_applicant.py
# ─────────────────────────────────────────────────────────────────────────────
# CHANGES FROM v1
# ─────────────────────────────────────────────────────────────────────────────
# Only submit_application changes.
# It now queues evaluate_proposal.delay(app.id) instead of running pipeline
# synchronously. The route signature and response schema are IDENTICAL.
#
# All other applicant routes (accepted, respond, notifications) are UNCHANGED.
# ─────────────────────────────────────────────────────────────────────────────

from fastapi import APIRouter, Depends, HTTPException

from .db import get_session
from .models import Application
from .auth import require_applicant, get_current_user, User  # your existing deps
from .tasks import evaluate_proposal                          # NEW import

router = APIRouter()


# ── Paste your existing applicant routes above this line, then replace only
#    submit_application below. ───────────────────────────────────────────────


# CHANGED — queues Celery task instead of running pipeline synchronously.
# Route path, method, and accepted payload are IDENTICAL.
@router.post("/submit_application")
def submit_application(data: dict, user: User = Depends(require_applicant)):
    tender_id = data.get("tender_id")
    if not tender_id:
        raise HTTPException(status_code=422, detail="tender_id is required")

    with get_session() as session:
        app = Application(
            tender_id=int(tender_id),
            user_id=user.id,
            applicant_text=data.get("text", ""),
            pdf_path=data.get("pdf_path"),   # optional: path to uploaded PDF
            status="submitted",
        )
        session.add(app)
        session.commit()
        session.refresh(app)
        app_id = app.id

    # Queue async scoring — bidder does NOT wait for LLM evaluation.
    # Celery picks this up from Redis and runs evaluate_proposal in the worker.
    evaluate_proposal.delay(app_id)

    return {"application_id": app_id, "status": "submitted"}
